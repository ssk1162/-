package com.project02.world42;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project02.world42.DAO.CmntDAO;
import com.project02.world42.DTO.CmntDTO;

@Controller
public class CmntController {

	@Autowired
	CmntDAO dao;
	
	@RequestMapping("cmnt.insert")
	public String insert(CmntDTO cmntDTO) {
		dao.cmntCreate(cmntDTO);
		return "redirect:index.jsp";
	}
	
	@RequestMapping("cmnt.read")
	public void read(CmntDTO cmntDTO, Model model) {
		CmntDTO result = dao.cmntRead(cmntDTO);
		model.addAttribute("cmntResult", result);
	}
	
}
