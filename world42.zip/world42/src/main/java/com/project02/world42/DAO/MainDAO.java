package com.project02.world42.DAO;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project02.world42.DTO.MainDTO;
import com.project02.world42.DTO.UsersDTO;

@Repository
public class MainDAO {

	@Autowired
	SqlSessionTemplate mybatis;
	
	public MainDTO mainRead(MainDTO mainDTO) {
		MainDTO dto = mybatis.selectOne("main.readAll", mainDTO);
		return dto;
	}
	
	public UsersDTO mainRead(UsersDTO usersDTO) {
		UsersDTO dto = mybatis.selectOne("main.readUser", usersDTO);
		return dto;
	}
	
	
}
