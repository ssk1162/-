package com.project02.world42;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project02.world42.DAO.MainDAO;
import com.project02.world42.DTO.MainDTO;
import com.project02.world42.DTO.UsersDTO;

@Controller
public class MainController {

	@Autowired
	MainDAO dao;

	@RequestMapping("main.home")
	public void mainRead(MainDTO mainDTO, UsersDTO usersDTO, Model model, HttpSession session) {
		session.setAttribute("sessionId", mainDTO.getMemid());
		MainDTO dto = dao.mainRead(mainDTO);
		System.out.println(mainDTO.getMemid());
		UsersDTO dto2 = dao.mainRead(usersDTO);
		model.addAttribute("main", dto);
		model.addAttribute("mainU", dto2);
	}

	@RequestMapping("main.diary")
	public String mainDiary(MainDTO mainDTO, Model model) {
		MainDTO dto = dao.mainRead(mainDTO);
		model.addAttribute("main", dto);
		return "diary";
	}

	@RequestMapping("main.photo")
	public String mainPhoto(MainDTO mainDTO, Model model) {
		MainDTO dto = dao.mainRead(mainDTO);
		model.addAttribute("main", dto);
		return "photo";
	}

	@RequestMapping("main.guest")
	public String mainGuest(MainDTO mainDTO, Model model) {
		MainDTO dto = dao.mainRead(mainDTO);
		model.addAttribute("main", dto);
		return "guest";
	}

	@RequestMapping("main.shop")
	public String mainShop(MainDTO mainDTO, Model model) {
		MainDTO dto = dao.mainRead(mainDTO);
		model.addAttribute("main", dto);
		return "shop";
	}
}
