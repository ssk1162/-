package com.project02.world42.DTO;

public class CmntDTO {
	private int cIdx;
	private int mIdx;
	private String memid;
	private String cCon;
	private String cDate;
	public int getcIdx() {
		return cIdx;
	}
	public void setcIdx(int cIdx) {
		this.cIdx = cIdx;
	}
	public int getmIdx() {
		return mIdx;
	}
	public void setmIdx(int mIdx) {
		this.mIdx = mIdx;
	}
	public String getcWri() {
		return memid;
	}
	public void setcWri(String memid) {
		this.memid = memid;
	}
	public String getcCon() {
		return cCon;
	}
	public void setcCon(String cCon) {
		this.cCon = cCon;
	}
	public String getcDate() {
		return cDate;
	}
	public void setcDate(String cDate) {
		this.cDate = cDate;
	}
	
}
