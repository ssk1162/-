package com.project02.world42.DAO;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project02.world42.DTO.CmntDTO;

@Repository
public class CmntDAO {

	@Autowired
	SqlSessionTemplate mybatis;
	
	public void cmntCreate(CmntDTO cmntDTO) {
		mybatis.insert("cmnt.insert", cmntDTO);
	}
	
	public CmntDTO cmntRead(CmntDTO cmntDTO) {
		CmntDTO dto = mybatis.selectOne("cmnt.select", cmntDTO);
		return dto;
	}
	
}
