//Updated 2021.08.09 오전 10:20

package rec;

public class RecDTO {
	
	private String proid;
	private String pronam;
	private String proprice;
	private String proimg;
	private String proadd;
	
	public String getProid() {
		return proid;
	}
	public void setProid(String proid) {
		this.proid = proid;
	}
	public String getPronam() {
		return pronam;
	}
	public void setPronam(String pronam) {
		this.pronam = pronam;
	}
	public String getProprice() {
		return proprice;
	}
	public void setProprice(String proprice) {
		this.proprice = proprice;
	}
	public String getProimg() {
		return proimg;
	}
	public void setProimg(String proimg) {
		this.proimg = proimg;
	}
	public String getProadd() {
		return proadd;
	}
	public void setProadd(String proadd) {
		this.proadd = proadd;
	}
}
